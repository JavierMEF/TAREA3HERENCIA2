package Herencia2;

public class Hervivoros {

}
