package Herencia2;

public class Animales {

}
