package Herencia2;

public class Carnivoros {

}
