package Herencia2;
/*
OrfanismoCelular:unicelulares o pluricelular
Tipo de desarrollo: mamiferos:Feed Back *negativo o metamorfosis insectos
Tipo de reproducción: asexual y sexual
Tipo:mamífero insecto 
*/
public class Seresvivos {
	private String tipo;
	private String tipoDesarrollo;
	private String tipoReproduccion;
	private String organismosCelulares;
	public Seresvivos(){
	  tipo="";
	  tipoDesarrollo="";
	  tipoReproduccion="";
	  organismoCelulsres="";
	}
	public Seresvivos(String tipo, String tipoDesarrollo, String tipoReproduccion, String organismosCelulares){
	  this.tipo;
	  this.tipoDesarrollo;
	  this.tipoReproduccion;
	  this.organismosCelulares;
	}
	public String getTipo(){
	  return tipo;
}
	public String
	public String
	public String
	public String
	public String
	public String
	public String
	
}
